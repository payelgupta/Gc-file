import { useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/hooks/useAuth";
import { KeyRound } from "lucide-react";
import { PasswordInput } from "@/components/ui/password-input";

const AdminAccount = () => {
  const { user } = useAuth();
  const { toast } = useToast();
  const [newEmail, setNewEmail] = useState("");
  const [newPassword, setNewPassword] = useState("");
  const [loading, setLoading] = useState(false);

  const handleUpdateEmail = async () => {
    if (!newEmail.trim()) return;
    setLoading(true);
    const { error } = await supabase.auth.updateUser({ email: newEmail });
    if (error) {
      toast({ title: "ব্যর্থ", description: error.message, variant: "destructive" });
    } else {
      toast({ title: "ইমেইল আপডেট হয়েছে!" });
      setNewEmail("");
    }
    setLoading(false);
  };

  const handleUpdatePassword = async () => {
    if (newPassword.length < 6) {
      toast({ title: "পাসওয়ার্ড কমপক্ষে ৬ অক্ষরের হতে হবে", variant: "destructive" });
      return;
    }
    setLoading(true);
    const { error } = await supabase.auth.updateUser({ password: newPassword });
    if (error) {
      toast({ title: "ব্যর্থ", description: error.message, variant: "destructive" });
    } else {
      toast({ title: "পাসওয়ার্ড আপডেট হয়েছে!" });
      setNewPassword("");
    }
    setLoading(false);
  };

  return (
    <div>
      <div className="flex items-center gap-3">
        <Button variant="ghost" size="sm" onClick={() => window.history.back()} className="gap-1.5">← ব্যাক</Button>
        <KeyRound className="h-7 w-7 text-primary" />
        <div>
          <h1 className="text-2xl font-bold text-foreground">অ্যাকাউন্ট সেটিংস</h1>
          <p className="text-sm text-muted-foreground">ইমেইল ও পাসওয়ার্ড পরিবর্তন করুন</p>
        </div>
      </div>

      <div className="mt-6 space-y-6">
        <div className="rounded-xl border border-border bg-card p-6">
          <p className="text-sm text-muted-foreground mb-4">বর্তমান ইমেইল: <span className="font-medium text-foreground">{user?.email}</span></p>
          <div className="space-y-4">
            <div>
              <Label>নতুন ইমেইল</Label>
              <Input type="email" value={newEmail} onChange={e => setNewEmail(e.target.value)} placeholder="new@gmail.com" />
            </div>
            <Button onClick={handleUpdateEmail} disabled={loading || !newEmail.trim()}>
              ইমেইল আপডেট করুন
            </Button>
          </div>
        </div>

        <div className="rounded-xl border border-border bg-card p-6">
          <div className="space-y-4">
            <div>
              <Label>নতুন পাসওয়ার্ড</Label>
              <PasswordInput value={newPassword} onChange={e => setNewPassword(e.target.value)} placeholder="কমপক্ষে ৬ অক্ষর" />
            </div>
            <Button onClick={handleUpdatePassword} disabled={loading || newPassword.length < 6}>
              পাসওয়ার্ড আপডেট করুন
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AdminAccount;
