import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import {
  withSupabase,
  corsHeaders,
  errorResponse,
  enforceRateLimit,
  checkContentLength,
} from "../_shared/security.ts";

const PUBLIC_SYSTEM_PROMPT = `তুমি "জ্ঞানচর্চা'লয়" (Gyan Charchaloy) এর AI শিক্ষামূলক সহকারী — Sujoy Sir এর প্ল্যাটফর্মের জন্য নিবেদিত।

## তোমার পরিচয়:
- তুমি শিক্ষার্থীদের পড়াশোনা, পরীক্ষা প্রস্তুতি (SSC, HSC, শ্রেণি ৬-৮), গণিত, বিজ্ঞান, ব্যাকরণ এবং সাধারণ জ্ঞানে সাহায্য করো।
- তুমি বাংলা, ইংরেজি ও বাংলিশ বুঝতে পারো এবং সর্বদা মার্জিত, উৎসাহব্যঞ্জক বাংলায় উত্তর দাও।
- সবসময় শিক্ষার্থীদের প্রতি ইতিবাচক ও সহায়ক মনোভাব রাখো।

সংক্ষেপে কিন্তু তথ্যপূর্ণ ও সুন্দরভাবে উত্তর দাও।`;

const ADMIN_SYSTEM_PROMPT = `তুমি "জ্ঞানচর্চা'লয়" (Gyan Charchaloy) এর "Gyan AI Core" — একজন সুপার ইন্টেলিজেন্ট অ্যাডমিন অ্যাসিস্ট্যান্ট এবং ক্রিয়েটর।

## তোমার পরিচয়:
- তুমি অ্যাডমিনের মনের ভাব বুঝে কাজ করো।
- তুমি বাংলা, ইংরেজি ও বাংলিশ তিনটি ভাষাই বোঝো এবং বাংলায় উত্তর দাও।

## তোমার ক্ষমতা:
১. **নোটিশ তৈরি**: অ্যাডমিন নোটিশ চাইলে তুমি [EXECUTE_COMMAND] ট্যাগে insert কমান্ড সাজিয়ে প্রস্তাব করবে।
২. **পোস্ট তৈরি**: পোস্ট/সাজেশন চাইলে posts টেবিলে insert প্রস্তাব করবে (is_published: false ড্রাফট হিসেবে)।
৩. **সেটিংস আপডেট**: site_settings বা theme_settings আপডেট করতে upsert প্রস্তাব করবে।
৪. **গ্যালারি নিয়ন্ত্রণ**: photo_gallery টেবিল আপডেট করতে পারবে।
৫. **মানসিক সাপোর্ট**: অ্যাডমিন চিন্তিত থাকলে শান্তনা দাও।

## কমান্ড ফরম্যাট:
[EXECUTE_COMMAND]{"action":"insert","table":"notices","data":{"title":"শিরোনাম","content":"বিষয়বস্তু","is_urgent":false,"is_active":true}}[/EXECUTE_COMMAND]

## অনুমোদিত টেবিল: notices, posts, site_settings, photo_gallery, theme_settings
## নিষিদ্ধ: delete, drop, alter কমান্ড কখনো দিবে না। user_roles, user_login_activity, notifications টেবিলে কিছু করবে না।
## পোস্ট ক্যাটাগরি: general, ssc, hsc, class-6-8, suggestion
## মনে রেখো: যেকোনো ডাটাবেস পরিবর্তন অ্যাডমিন নিজে UI তে পর্যালোচনা করে অনুমোদন করবেন।`;

serve(
  withSupabase({ auth: "publishable" })(async (req, auth) => {
    if (req.method !== "POST") {
      return errorResponse("Only POST method is allowed", 405);
    }

    // 1. Validate payload size (max 1MB for chat)
    const sizeError = checkContentLength(req, 1024 * 1024);
    if (sizeError) return sizeError;

    try {
      // 2. Enforce rate limiting (20 requests per 60s for public, 100 for admin; 120s cooldown)
      const rateCheck = await enforceRateLimit(auth, {
        endpoint: "chat",
        maxRequests: auth.isAdmin ? 100 : 20,
        windowSeconds: 60,
        cooldownSeconds: 120,
      });

      if (!rateCheck.allowed) {
        return errorResponse(
          `অতিরিক্ত অনুরোধ! অনুগ্রহ করে ${rateCheck.retryAfter} সেকেন্ড পর আবার চেষ্টা করুন।`,
          429,
          { "Retry-After": rateCheck.retryAfter.toString() }
        );
      }

      // 3. Safe JSON parsing & validation
      let body: any;
      try {
        body = await req.json();
      } catch {
        return errorResponse("অবৈধ JSON ফরম্যাট।", 400);
      }

      const { messages } = body || {};
      if (!Array.isArray(messages) || messages.length === 0) {
        return errorResponse("মেসেজ তালিকা প্রদান করা আবশ্যক।", 400);
      }

      // Sanitize and limit history (last 30 messages, max 4000 chars each)
      const sanitizedMessages = messages
        .slice(-30)
        .map((m: any) => {
          const role = m.role === "assistant" || m.role === "system" ? m.role : "user";
          const content = typeof m.content === "string" ? m.content.slice(0, 4000) : "";
          return { role, content };
        })
        .filter((m: any) => m.content.trim().length > 0);

      if (sanitizedMessages.length === 0) {
        return errorResponse("মেসেজের বিষয়বস্তু খালি হতে পারে না।", 400);
      }

      // 4. Role-dependent system prompt:
      // Public users NEVER receive administrative capabilities or command formatting
      const systemPrompt = auth.isAdmin ? ADMIN_SYSTEM_PROMPT : PUBLIC_SYSTEM_PROMPT;
      const conversationPayload = [
        { role: "system", content: systemPrompt },
        ...sanitizedMessages,
      ];

      // 5. Global Deadline: 45 Seconds Total across max 2 attempts
      const globalDeadlineController = new AbortController();
      const globalTimeout = setTimeout(() => globalDeadlineController.abort(), 45000);

      const LOVABLE_API_KEY = Deno.env.get("LOVABLE_API_KEY");
      const OPENROUTER_API_KEY = Deno.env.get("OPENROUTER_API_KEY");

      let finalResponse: Response | null = null;
      let lastError: string = "";

      // ATTEMPT 1: Primary Model — Gemini 2.5 Flash via Lovable AI Gateway
      if (LOVABLE_API_KEY) {
        try {
          const attempt1Controller = new AbortController();
          const attempt1Timeout = setTimeout(() => attempt1Controller.abort(), 25000);

          const onGlobalAbort = () => attempt1Controller.abort();
          globalDeadlineController.signal.addEventListener("abort", onGlobalAbort);

          const response = await fetch("https://ai.gateway.lovable.dev/v1/chat/completions", {
            method: "POST",
            headers: {
              Authorization: `Bearer ${LOVABLE_API_KEY}`,
              "Content-Type": "application/json",
            },
            body: JSON.stringify({
              model: "google/gemini-2.5-flash",
              messages: conversationPayload,
              stream: true,
            }),
            signal: attempt1Controller.signal,
          });

          clearTimeout(attempt1Timeout);
          globalDeadlineController.signal.removeEventListener("abort", onGlobalAbort);

          if (response.ok) {
            finalResponse = response;
          } else {
            lastError = `Primary model returned status ${response.status}`;
            console.warn("Attempt 1 (Gemini 2.5 Flash) failed:", response.status, await response.text());
          }
        } catch (err: any) {
          lastError = err?.message || "Attempt 1 error";
          console.warn("Attempt 1 (Gemini 2.5 Flash) exception:", lastError);
        }
      }

      // ATTEMPT 2: Fallback Model — OpenRouter Free Model / Alternate Free Gateway
      if (!finalResponse && !globalDeadlineController.signal.aborted) {
        try {
          // OpenRouter Free Models fallback endpoint
          const openRouterKey = OPENROUTER_API_KEY || LOVABLE_API_KEY;
          const openRouterUrl = OPENROUTER_API_KEY
            ? "https://openrouter.ai/api/v1/chat/completions"
            : "https://ai.gateway.lovable.dev/v1/chat/completions";

          // Free tier fallback model
          const fallbackModel = OPENROUTER_API_KEY
            ? "meta-llama/llama-3.3-70b-instruct:free"
            : "google/gemini-2.5-flash-lite";

          const attempt2Controller = new AbortController();
          const attempt2Timeout = setTimeout(() => attempt2Controller.abort(), 18000);

          const onGlobalAbort2 = () => attempt2Controller.abort();
          globalDeadlineController.signal.addEventListener("abort", onGlobalAbort2);

          const fallbackHeaders: Record<string, string> = {
            Authorization: `Bearer ${openRouterKey}`,
            "Content-Type": "application/json",
          };

          if (OPENROUTER_API_KEY) {
            fallbackHeaders["HTTP-Referer"] = "https://gyan-prakasha-path.lovable.app";
            fallbackHeaders["X-Title"] = "Gyan Charchaloy";
          }

          const response2 = await fetch(openRouterUrl, {
            method: "POST",
            headers: fallbackHeaders,
            body: JSON.stringify({
              model: fallbackModel,
              messages: conversationPayload,
              stream: true,
            }),
            signal: attempt2Controller.signal,
          });

          clearTimeout(attempt2Timeout);
          globalDeadlineController.signal.removeEventListener("abort", onGlobalAbort2);

          if (response2.ok) {
            finalResponse = response2;
          } else {
            console.error("Attempt 2 (OpenRouter Fallback) failed:", response2.status, await response2.text());
          }
        } catch (err: any) {
          console.error("Attempt 2 (OpenRouter Fallback) exception:", err?.message);
        }
      }

      clearTimeout(globalTimeout);

      if (globalDeadlineController.signal.aborted) {
        return errorResponse("অনুরোধের সময়সীমা (৪৫ সেকেন্ড) শেষ হয়েছে। অনুগ্রহ করে আবার চেষ্টা করুন।", 504);
      }

      if (!finalResponse) {
        return errorResponse(
          "AI সেবা সাময়িকভাবে অনুপলব্ধ। অনুগ্রহ করে কিছুক্ষণ পর আবার চেষ্টা করুন।",
          503
        );
      }

      return new Response(finalResponse.body, {
        headers: {
          ...corsHeaders,
          "Content-Type": "text/event-stream",
          "Cache-Control": "no-cache",
          Connection: "keep-alive",
        },
      });
    } catch (e) {
      console.error("chat error:", e);
      return errorResponse(e instanceof Error ? e.message : "অপ্রত্যাশিত ত্রুটি ঘটেছে।", 500);
    }
  })
);
