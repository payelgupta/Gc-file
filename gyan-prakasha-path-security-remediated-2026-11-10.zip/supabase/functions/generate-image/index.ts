import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import {
  withSupabase,
  corsHeaders,
  errorResponse,
  enforceRateLimit,
  checkContentLength,
} from "../_shared/security.ts";

serve(
  withSupabase({ auth: "publishable" })(async (req, auth) => {
    if (req.method !== "POST") {
      return errorResponse("Only POST method is allowed", 405);
    }

    // 1. Content size validation (max 512KB for prompt payload)
    const sizeError = checkContentLength(req, 512 * 1024);
    if (sizeError) return sizeError;

    try {
      // 2. Rate limiting (5 requests per 60s for public, 25 for admin; 180s cooldown)
      const rateCheck = await enforceRateLimit(auth, {
        endpoint: "generate-image",
        maxRequests: 5,
        windowSeconds: 60,
        cooldownSeconds: 180,
      });

      if (!rateCheck.allowed) {
        return errorResponse(
          `ছবি তৈরির অনুরোধের সীমা অতিক্রম করেছে। অনুগ্রহ করে ${rateCheck.retryAfter} সেকেন্ড পর চেষ্টা করুন।`,
          429,
          { "Retry-After": rateCheck.retryAfter.toString() }
        );
      }

      // 3. Safe JSON parsing & prompt validation
      let body: any;
      try {
        body = await req.json();
      } catch {
        return errorResponse("অবৈধ JSON ফরম্যাট।", 400);
      }

      const rawPrompt = body?.prompt;
      if (typeof rawPrompt !== "string" || !rawPrompt.trim()) {
        return errorResponse("ছবির প্রম্পট প্রদান করা আবশ্যক।", 400);
      }

      const prompt = rawPrompt.trim().slice(0, 1000);
      if (prompt.length < 2) {
        return errorResponse("প্রম্পট অন্তত ২ অক্ষরের হতে হবে।", 400);
      }

      const LOVABLE_API_KEY = Deno.env.get("LOVABLE_API_KEY");

      // Source 1: Lovable AI Gateway (Gemini image model)
      if (LOVABLE_API_KEY) {
        try {
          const controller = new AbortController();
          const timeoutId = setTimeout(() => controller.abort(), 25000);

          const response = await fetch("https://ai.gateway.lovable.dev/v1/chat/completions", {
            method: "POST",
            headers: {
              Authorization: `Bearer ${LOVABLE_API_KEY}`,
              "Content-Type": "application/json",
            },
            body: JSON.stringify({
              model: "google/gemini-3.1-flash-image-preview",
              messages: [{ role: "user", content: `Generate an educational or artistic image: ${prompt}` }],
              modalities: ["image", "text"],
            }),
            signal: controller.signal,
          });

          clearTimeout(timeoutId);

          if (response.ok) {
            const data = await response.json();
            const imageData = data.choices?.[0]?.message?.images?.[0]?.image_url?.url;
            if (imageData) {
              return new Response(
                JSON.stringify({ source: "lovable-ai", imageUrl: imageData, success: true }),
                { headers: { ...corsHeaders, "Content-Type": "application/json" } }
              );
            }
          }
        } catch (e) {
          console.warn("Lovable AI image generation fallback triggered:", e);
        }
      }

      // Source 2: Pollinations.ai - free safe fallback
      try {
        const encodedPrompt = encodeURIComponent(prompt);
        const pollinationsUrl = `https://image.pollinations.ai/prompt/${encodedPrompt}?width=512&height=512&nologo=true&safe=true`;

        const controller = new AbortController();
        const timeoutId = setTimeout(() => controller.abort(), 10000);

        const pollCheck = await fetch(pollinationsUrl, { method: "HEAD", signal: controller.signal });
        clearTimeout(timeoutId);

        if (pollCheck.ok || pollCheck.status === 302 || pollCheck.status === 301) {
          return new Response(
            JSON.stringify({ source: "pollinations", imageUrl: pollinationsUrl, success: true }),
            { headers: { ...corsHeaders, "Content-Type": "application/json" } }
          );
        }
      } catch (e) {
        console.warn("Pollinations source fallback triggered:", e);
      }

      return new Response(
        JSON.stringify({
          success: false,
          message: "ছবি তৈরি করা সম্ভব হয়নি। অনুগ্রহ করে কিছুক্ষণ পর আবার চেষ্টা করুন।",
        }),
        { headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    } catch (e) {
      console.error("generate-image error:", e);
      return errorResponse(e instanceof Error ? e.message : "অপ্রত্যাশিত ত্রুটি ঘটেছে।", 500);
    }
  })
);
