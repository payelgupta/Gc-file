import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.48.1";
import { withSupabase, corsHeaders, errorResponse, checkContentLength } from "../_shared/security.ts";

/**
 * get-premium-pdf
 * Secure Edge Function delivering short-lived (300s) signed URLs for paid PDF content.
 * 
 * AUDIT REMEDIATION (ISSUE 1):
 * - Resolves PDF paths exclusively from trusted database records (never client-supplied paths).
 * - Enforces canonical storage path conventions and strict project structure.
 * - Performs server-side ownership validation: rejects cross-post paths, path traversal,
 *   malformed filenames, foreign UUID prefixes, and database records referencing other posts' objects.
 * - Enforces 300-second TTL on signed URLs.
 */
serve(withSupabase({ auth: "required" })(async (req, auth) => {
  if (req.method !== "POST") return errorResponse("Only POST method is allowed", 405);
  const sizeError = checkContentLength(req, 16 * 1024);
  if (sizeError) return sizeError;

  let body: { post_id?: unknown; chapter_index?: unknown };
  try {
    body = await req.json();
  } catch {
    return errorResponse("Invalid JSON payload", 400);
  }

  const postId = typeof body.post_id === "string" ? body.post_id.trim().toLowerCase() : "";
  const uuidRegex = /^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i;
  if (!uuidRegex.test(postId)) {
    return errorResponse("A valid post_id is required", 400);
  }

  // Validate chapter_index if supplied: must be a non-negative integer
  const isChapterRequest = body.chapter_index !== undefined;
  let validatedChapterIndex: number | null = null;
  if (isChapterRequest) {
    if (
      typeof body.chapter_index !== "number" ||
      !Number.isInteger(body.chapter_index) ||
      body.chapter_index < 0
    ) {
      return errorResponse("চ্যাপ্টার ইনডেক্স একটি সঠিক অঋণাত্মক পূর্ণসংখ্যা (non-negative integer) হতে হবে।", 400);
    }
    validatedChapterIndex = body.chapter_index;
  }

  const supabaseUrl = Deno.env.get("SUPABASE_URL");
  const serviceRoleKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY");
  if (!supabaseUrl || !serviceRoleKey || !auth.userId) {
    return errorResponse("Premium file service is not configured", 503);
  }

  const admin = createClient(supabaseUrl, serviceRoleKey, {
    auth: { persistSession: false, autoRefreshToken: false },
  });

  try {
    // 1. Fetch authorized post record from database
    const { data: post, error: postError } = await admin
      .from("posts")
      .select("id, is_paid, is_published, chapters")
      .eq("id", postId)
      .maybeSingle();
    if (postError) throw postError;
    if (!post) return errorResponse("পোস্টটি পাওয়া যায়নি।", 404);
    if (post.is_paid !== true) return errorResponse("এই পোস্টে প্রিমিয়াম PDF সক্রিয় নেই।", 409);
    if (!auth.isAdmin && post.is_published !== true) {
      return errorResponse("এই PDF বর্তমানে প্রকাশিত নয়।", 404);
    }

    // 2. Authorization check: Admin or approved student
    if (!auth.isAdmin) {
      const { data: approval, error: approvalError } = await admin
        .from("pdf_unlock_requests")
        .select("id")
        .eq("post_id", postId)
        .eq("user_id", auth.userId)
        .eq("status", "approved")
        .limit(1)
        .maybeSingle();
      if (approvalError) throw approvalError;
      if (!approval) return errorResponse("এই PDF দেখার অনুমতি নেই। কোর্সটি আনলক করুন।", 403);
    }

    let objectPath = "";

    // 3. Resolve canonical path strictly from database
    if (isChapterRequest && validatedChapterIndex !== null) {
      if (!Array.isArray(post.chapters) || validatedChapterIndex >= post.chapters.length) {
        return errorResponse("অনুরোধকৃত চ্যাপ্টার পাওয়া যায়নি।", 404);
      }

      const chapter = post.chapters[validatedChapterIndex] as { url?: string; title?: string } | undefined;
      const canonicalUrl = typeof chapter?.url === "string" ? chapter.url.trim() : "";

      if (!canonicalUrl) {
        return errorResponse("এই চ্যাপ্টারের জন্য কোনো PDF ফাইল যুক্ত নেই।", 404);
      }

      // Legacy public HTTP URLs must undergo migration before signed URL generation
      if (canonicalUrl.startsWith("http://") || canonicalUrl.startsWith("https://")) {
        console.error("Legacy public URL found in post chapters; manual migration required", {
          postId,
          chapterIndex: validatedChapterIndex,
          canonicalUrl,
        });
        return errorResponse("এই পুরোনো চ্যাপ্টার PDF নিরাপদ Private Storage-এ স্থানান্তর করতে হবে।", 409);
      }

      // Strip approved private bucket prefix
      objectPath = canonicalUrl.startsWith("premium-pdfs/")
        ? canonicalUrl.slice("premium-pdfs/".length)
        : canonicalUrl;

      // Validate basic storage path safety
      if (
        !objectPath ||
        objectPath.startsWith("/") ||
        objectPath.includes("..") ||
        objectPath.includes("//") ||
        objectPath.includes("\\") ||
        !/^[a-zA-Z0-9_./-]+$/.test(objectPath) ||
        !objectPath.toLowerCase().endsWith(".pdf") ||
        !objectPath.startsWith("chapters/")
      ) {
        return errorResponse("অবৈধ চ্যাপ্টার ফাইল পাথ।", 400);
      }

      // OWNERSHIP VALIDATION: Check if filename starts with a UUID prefix
      const filename = objectPath.split("/").pop() || "";
      const uuidPrefixMatch = filename.match(/^([0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12})(-|$)/i);
      if (uuidPrefixMatch) {
        const embeddedUuid = uuidPrefixMatch[1].toLowerCase();
        if (embeddedUuid !== postId) {
          console.error("SECURITY VIOLATION: Cross-post chapter file detected in post record!", {
            postId,
            chapterIndex: validatedChapterIndex,
            embeddedUuid,
            objectPath,
          });
          return errorResponse("অননুমোদিত স্টোরেজ অবজেক্ট: এই ফাইলটি অন্য কোর্সের অন্তর্ভুক্ত।", 403);
        }
      }

      // Check if another post exclusively owns this exact file URL in premium_files
      const { data: foreignFile } = await admin
        .from("premium_files")
        .select("post_id")
        .eq("file_url", objectPath)
        .neq("post_id", postId)
        .limit(1)
        .maybeSingle();

      if (foreignFile) {
        console.error("SECURITY VIOLATION: Chapter path belongs to another post in premium_files!", {
          postId,
          foreignPostId: foreignFile.post_id,
          objectPath,
        });
        return errorResponse("অননুমোদিত স্টোরেজ অবজেক্ট: এই ফাইলটি অন্য কোর্সের জন্য নির্ধারিত।", 403);
      }
    } else {
      // Main post PDF retrieval from premium_files table
      const { data: file, error: fileError } = await admin
        .from("premium_files")
        .select("file_url")
        .eq("post_id", postId)
        .maybeSingle();
      if (fileError) throw fileError;
      if (!file?.file_url) return errorResponse("Premium PDF পাওয়া যায়নি।", 404);

      const canonicalFileUrl = file.file_url.trim();
      if (canonicalFileUrl.startsWith("http://") || canonicalFileUrl.startsWith("https://")) {
        console.error("Legacy public URL found in premium_files; manual migration required", { postId });
        return errorResponse("এই পুরোনো PDF নিরাপদ Private Storage-এ স্থানান্তর করতে হবে।", 409);
      }

      objectPath = canonicalFileUrl.startsWith("premium-pdfs/")
        ? canonicalFileUrl.slice("premium-pdfs/".length)
        : canonicalFileUrl;

      // Validate basic path safety
      if (
        !objectPath ||
        objectPath.startsWith("/") ||
        objectPath.includes("..") ||
        objectPath.includes("//") ||
        objectPath.includes("\\") ||
        !/^[a-zA-Z0-9_./-]+$/.test(objectPath) ||
        !objectPath.toLowerCase().endsWith(".pdf") ||
        (!objectPath.startsWith("pdfs/") && !objectPath.startsWith("migrated-legacy/") && !objectPath.startsWith("chapters/"))
      ) {
        return errorResponse("অবৈধ ফাইল পাথ।", 400);
      }

      // OWNERSHIP VALIDATION for main PDF
      const filename = objectPath.split("/").pop() || "";
      const uuidPrefixMatch = filename.match(/^([0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12})(-|$)/i);
      if (uuidPrefixMatch) {
        const embeddedUuid = uuidPrefixMatch[1].toLowerCase();
        // If the path is under migrated-legacy or chapters and has a post UUID prefix, it must match postId
        if (
          (objectPath.startsWith("migrated-legacy/") || objectPath.startsWith("chapters/")) &&
          embeddedUuid !== postId
        ) {
          console.error("SECURITY VIOLATION: Cross-post main PDF detected in premium_files record!", {
            postId,
            embeddedUuid,
            objectPath,
          });
          return errorResponse("অননুমোদিত স্টোরেজ অবজেক্ট: এই ফাইলটি অন্য কোর্সের অন্তর্ভুক্ত।", 403);
        }
      }
    }

    // Signed URL expiration strictly set to 300 seconds (5 minutes)
    const expiresIn = 300;
    const { data: signed, error: signedError } = await admin.storage
      .from("premium-pdfs")
      .createSignedUrl(objectPath, expiresIn);
    if (signedError || !signed?.signedUrl) {
      throw signedError || new Error("Could not create signed URL");
    }

    return new Response(JSON.stringify({ success: true, signedUrl: signed.signedUrl, expiresIn }), {
      status: 200,
      headers: {
        ...corsHeaders,
        "Content-Type": "application/json",
        "Cache-Control": "no-store, no-cache, must-revalidate",
      },
    });
  } catch (error) {
    console.error("get-premium-pdf error:", error);
    return errorResponse("PDF লিংক তৈরি করা যায়নি। পরে আবার চেষ্টা করুন।", 500);
  }
}));
