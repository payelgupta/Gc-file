import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import {
  withSupabase,
  corsHeaders,
  errorResponse,
  enforceRateLimit,
  checkContentLength,
} from "../_shared/security.ts";

serve(
  withSupabase({ auth: "publishable" })(async (req, auth) => {
    if (req.method !== "POST") {
      return errorResponse("Only POST method is allowed", 405);
    }

    // 1. Content size validation (max 512KB)
    const sizeError = checkContentLength(req, 512 * 1024);
    if (sizeError) return sizeError;

    try {
      // 2. Rate limiting (3 requests per 60s for public, 15 for admin; 300s cooldown)
      const rateCheck = await enforceRateLimit(auth, {
        endpoint: "generate-video",
        maxRequests: 3,
        windowSeconds: 60,
        cooldownSeconds: 300,
      });

      if (!rateCheck.allowed) {
        return errorResponse(
          `ভিডিও তৈরির অনুরোধের সীমা অতিক্রম করেছে। অনুগ্রহ করে ${rateCheck.retryAfter} সেকেন্ড পর চেষ্টা করুন।`,
          429,
          { "Retry-After": rateCheck.retryAfter.toString() }
        );
      }

      // 3. Safe JSON parsing & prompt validation
      let body: any;
      try {
        body = await req.json();
      } catch {
        return errorResponse("অবৈধ JSON ফরম্যাট।", 400);
      }

      const rawPrompt = body?.prompt;
      if (typeof rawPrompt !== "string" || !rawPrompt.trim()) {
        return errorResponse("ভিডিওর প্রম্পট প্রদান করা আবশ্যক।", 400);
      }

      const prompt = rawPrompt.trim().slice(0, 800);
      if (prompt.length < 3) {
        return errorResponse("প্রম্পট অন্তত ৩ অক্ষরের হতে হবে।", 400);
      }

      const HF_API_KEY = Deno.env.get("HF_API_KEY");

      // Source 1: HuggingFace video model
      if (HF_API_KEY) {
        try {
          const controller = new AbortController();
          const timeoutId = setTimeout(() => controller.abort(), 35000);

          const hfResponse = await fetch(
            "https://api-inference.huggingface.co/models/ali-vilab/text-to-video-ms-1.7b",
            {
              method: "POST",
              headers: {
                Authorization: `Bearer ${HF_API_KEY}`,
                "Content-Type": "application/json",
              },
              body: JSON.stringify({ inputs: prompt }),
              signal: controller.signal,
            }
          );

          clearTimeout(timeoutId);

          if (hfResponse.ok) {
            const contentType = hfResponse.headers.get("content-type") || "";
            if (contentType.includes("video") || contentType.includes("octet-stream")) {
              const videoData = await hfResponse.arrayBuffer();
              const bytes = new Uint8Array(videoData);
              let binary = "";
              const len = bytes.byteLength;
              for (let i = 0; i < len; i++) {
                binary += String.fromCharCode(bytes[i]);
              }
              const base64 = btoa(binary);

              return new Response(
                JSON.stringify({
                  source: "huggingface",
                  videoUrl: `data:video/mp4;base64,${base64}`,
                  success: true,
                }),
                { headers: { ...corsHeaders, "Content-Type": "application/json" } }
              );
            }
          }
        } catch (e) {
          console.warn("HuggingFace video fallback triggered:", e);
        }
      }

      // Source 2: Pollinations video
      try {
        const encodedPrompt = encodeURIComponent(prompt);
        const pollinationsUrl = `https://video.pollinations.ai/prompt/${encodedPrompt}`;

        const controller = new AbortController();
        const timeoutId = setTimeout(() => controller.abort(), 12000);

        const pollCheck = await fetch(pollinationsUrl, { method: "HEAD", signal: controller.signal });
        clearTimeout(timeoutId);

        if (pollCheck.ok || pollCheck.status === 302 || pollCheck.status === 301) {
          return new Response(
            JSON.stringify({
              source: "pollinations",
              videoUrl: pollinationsUrl,
              success: true,
            }),
            { headers: { ...corsHeaders, "Content-Type": "application/json" } }
          );
        }
      } catch (e) {
        console.warn("Pollinations video fallback triggered:", e);
      }

      // Safe fallback message
      return new Response(
        JSON.stringify({
          success: false,
          fallbackUrl: "https://veoaifree.com/",
          message: "সব ভিডিও সোর্স সাময়িকভাবে ব্যস্ত। অনুগ্রহ করে কিছুক্ষণ পর চেষ্টা করুন।",
        }),
        { headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    } catch (e) {
      console.error("generate-video error:", e);
      return errorResponse(e instanceof Error ? e.message : "অপ্রত্যাশিত ত্রুটি ঘটেছে।", 500);
    }
  })
);
